#!/root/soft/anaconda3/envs/tjenv/bin/python

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import savgol_filter

def normalize_y(data, column_name='Y', scale=10):
    data[column_name] = pd.to_numeric(data[column_name], errors='coerce')
    data = data.dropna(subset=[column_name]) 
    max_abs_value = data[column_name].abs().max()
    if max_abs_value != 0:
        data[column_name] = data[column_name] / max_abs_value * scale  
    return data

def clip_y_in_range(data, column_name='Y', x_column='X', x_range=(200, 600), y_range=(-10, 10)):
    data_in_range = data[(data[x_column] >= x_range[0]) & (data[x_column] <= x_range[1])]
    if not data_in_range.empty:
        data.loc[(data[x_column] >= x_range[0]) & (data[x_column] <= x_range[1]), column_name] = \
            data_in_range[column_name].clip(y_range[0], y_range[1])
    return data

def smooth_data(data, column_name='Y', window_length=31, polyorder=2):
    data[column_name] = savgol_filter(data[column_name], window_length=window_length, polyorder=polyorder)
    return data

def linear_fit(data, x_column='X', y_column='Y', fit_range=(280, 600)):
    fit_data = data[(data[x_column] >= fit_range[0]) & (data[x_column] <= fit_range[1])]
    if fit_data.empty:
        return data

    coef = np.polyfit(fit_data[x_column], fit_data[y_column], 1)
    linear_model = np.poly1d(coef)

    data.loc[(data[x_column] >= fit_range[0]) & (data[x_column] <= fit_range[1]), y_column] = \
        linear_model(data.loc[(data[x_column] >= fit_range[0]) & (data[x_column] <= fit_range[1]), x_column])
    return data

def process_and_plot(csv_file, txt_file):
    data1 = pd.read_csv(csv_file, header=None)

    if data1.shape[1] >= 2:
        data1 = data1.iloc[:, [0, 1]]
        data1.columns = ['X', 'Y']
    else:
        raise ValueError(f"The file {csv_file} does not have enough columns.")

    data1['X'] = pd.to_numeric(data1['X'], errors='coerce')
    data1['Y'] = pd.to_numeric(data1['Y'], errors='coerce')
    data1 = data1.dropna(subset=['X', 'Y'])

    data1 = data1.iloc[1:445]
    data1 = data1[(data1['X'] >= 200) & (data1['X'] <= 600)]

    data1 = normalize_y(data1)
    data1 = clip_y_in_range(data1)

    data1 = smooth_data(data1, window_length=51, polyorder=3)
    data1 = linear_fit(data1, fit_range=(550, 600))

    data2 = pd.read_csv(txt_file, sep='\s+', header=None)
    data2.columns = ['X', 'Y']

    data2['X'] = pd.to_numeric(data2['X'], errors='coerce')
    data2['Y'] = pd.to_numeric(data2['Y'], errors='coerce')
    data2 = data2.dropna(subset=['X', 'Y'])

    data2 = data2[(data2['X'] >= 200) & (data2['X'] <= 600)]
    data2 = normalize_y(data2)
    data2 = smooth_data(data2, window_length=31, polyorder=2)

    # Create dataset 3 as a mirrored version of dataset 2
    data3 = data2.copy()
    data3['Y'] = -data2['Y']


    plt.figure(figsize=(12, 9))  
    plt.plot(data1['X'], data1['Y'], color='blue', linestyle='-', marker='o', markersize=4)
    plt.plot(data2['X'], data2['Y'], color='red', linestyle='-', marker='x', markersize=4)

    plt.axhline(0, color='black', linewidth=0.8, linestyle='--')
    plt.axvline(200, color='black', linewidth=0.8)
    plt.xlim(200, 600)
    plt.ylim(-12, 12)
    plt.xticks(range(200, 601, 20), fontsize=14, fontweight='bold')
    plt.yticks(range(-12, 13, 2), fontsize=14, fontweight='bold')

    plt.xlabel('Wavelength (nm)', fontsize=16, fontweight='bold')
    plt.ylabel('Δε (M⁻¹ cm⁻¹)', fontsize=16, fontweight='bold')
    plt.title(f'Combined XY Curves', fontsize=18, fontweight='bold')

    plt.grid(False)

    output_file = f"{os.path.splitext(os.path.basename(csv_file))[0]}_p01.jpg"
    plt.savefig(output_file, format='jpg', dpi=300)  
    plt.close()
    print(f"Plot saved: {output_file}")

def main():
    input_folder = os.path.dirname(os.path.abspath(__file__))

    csv_files = [f for f in os.listdir(input_folder) if f.endswith(".csv")]
    txt_files = [f for f in os.listdir(input_folder) if f.endswith(".txt")]

    for csv_file in csv_files:
        base_name = os.path.splitext(csv_file)[0]
        txt_file = f"{base_name}.txt"
        csv_path = os.path.join(input_folder, csv_file)
        txt_path = os.path.join(input_folder, txt_file)

        if txt_file in txt_files:
            process_and_plot(csv_path, txt_path)

if __name__ == "__main__":
    main()
