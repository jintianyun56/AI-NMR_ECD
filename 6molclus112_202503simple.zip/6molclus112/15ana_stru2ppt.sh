#!/bin/bash
echo "🔹 Activating conda environment..."
source /root/soft/anaconda3/etc/profile.d/conda.sh  # 兼容不同 Shell
conda activate tjenv




    
    vmd -dispdev text -e render_vmd.tcl -eofexit
    ./fig2ppt.py

conda deactivate



# 计算脚本运行时间（以秒为单位）
end_time=$(date +%s)
runtime=$((end_time - start_time))

# 将秒数转换成小时
hours=$((runtime / 3600))
minutes=$((runtime / 60))
hostname=$(hostname)

echo "$hostname $hours 小时 $minutes 分钟 molclus+ done" | mail -s "$hostname $hours 小时 $minutes 分钟 molclus+ done" 944671929@qq.com




