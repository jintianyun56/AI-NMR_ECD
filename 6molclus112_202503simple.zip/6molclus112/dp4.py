#!/root/soft/anaconda3/envs/tjenv/bin/python
# Evaluate the averaged NMR chemical shifts

import os
import pandas as pd
from glob import glob

def extract_and_concatenate(file_patterns, sheet_names):
    """Extract the 3rd and 4th columns from matching files and consolidate into Excel sheets."""
    
    # Initialize empty DataFrames for consolidated data
    all_column3_df = pd.DataFrame()
    all_column4_df = pd.DataFrame()
    
    # Dictionary to store individual data frames for each sheet
    sheet_data = {}

    for file_pattern, sheet_name in zip(file_patterns, sheet_names):
        column3_df = pd.DataFrame()
        column4_df = pd.DataFrame()
        file_names = []

        # Loop through matching files
        for file in sorted(glob(file_pattern)):  # Sorted to maintain order
            base_name = os.path.splitext(file)[0]  # Extract base name

            # Extract the third and fourth columns starting from the second row
            data_df = pd.read_table(file, sep='\s+', skiprows=1, usecols=[2, 3], header=None, names=['Shielding', 'Chemical_Shift'])

            # Concatenate the columns horizontally
            column3_df = pd.concat([column3_df, data_df['Shielding']], axis=1)
            column4_df = pd.concat([column4_df, data_df['Chemical_Shift']], axis=1)
            file_names.append(base_name)

        # Store extracted data with proper column names
        column3_df.columns = file_names
        column4_df.columns = file_names
        
        # Save individual sheet data
        sheet_data[f'{sheet_name}_Shielding'] = column3_df
        sheet_data[f'{sheet_name}_Chemical_Shift'] = column4_df

        # Concatenate for consolidated sheets
        all_column3_df = pd.concat([all_column3_df, column3_df], axis=1)
        all_column4_df = pd.concat([all_column4_df, column4_df], axis=1)

    # Add consolidated data to dictionary (ensuring they are placed first)
    sheet_data = {
        'Consolidated_Shielding': all_column3_df,
        'Consolidated_Chemical_Shift': all_column4_df,
        **sheet_data  # Append the remaining sheets
    }

    return sheet_data

# Save the extracted data to an Excel file
excel_file = 'extracted_data_combined_with_names.xlsx'
file_patterns = [
    '*_09_CWeighted01.txt', '*_09_HWeighted01.txt',
    '*_09_CWeighted02.txt', '*_09_HWeighted02.txt',
    '*_09_CWeighted03.txt', '*_09_HWeighted03.txt'
]
sheet_names = ['CWeighted01', 'HWeighted01', 'CWeighted02', 'HWeighted02', 'CWeighted03', 'HWeighted03']

# Extract data
sheet_data = extract_and_concatenate(file_patterns, sheet_names)

# Write to Excel ensuring `Consolidated_Shielding` and `Consolidated_Chemical_Shift` are first
with pd.ExcelWriter(excel_file, engine='xlsxwriter') as writer:
    for sheet_name, df in sheet_data.items():
        df.to_excel(writer, sheet_name=sheet_name, index=False)

print(f'✅ Extracted data with file names saved to {excel_file}')
