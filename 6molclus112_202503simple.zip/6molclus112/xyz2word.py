#!/root/soft/anaconda3/envs/tjenv/bin/python
# Process XYZ files and generate a formatted Word document

import os
import re
from docx import Document
from docx.shared import Pt
from docx.oxml.ns import qn

def adjust_spacing(text):
    """将多于4个空格的部分缩小至3个空格"""
    return re.sub(r'\s{4,}', '   ', text)

def format_xyz_line(line):
    """
    处理 XYZ 坐标行：
    - 提取元素名 + 坐标值
    - 确保 X, Y, Z 坐标数值保留 6 位有效数字
    """
    parts = line.strip().split()
    if len(parts) == 4:  # 确保是 XYZ 坐标行
        try:
            atom = parts[0]  # 元素名
            x, y, z = map(float, parts[1:])  # 转换为浮点数
            return f"{atom:<2} {x: .6f} {y: .6f} {z: .6f}"  # 6 位有效数字
        except ValueError:
            return line  # 若转换失败，保持原样
    return line  # 非 XYZ 坐标行，保持原样

# 初始化 Word 文档
doc = Document()

# 设置页面为两栏
section = doc.sections[0]
sectPr = section._sectPr
cols = sectPr.xpath('./w:cols')[0]
cols.set(qn('w:num'), '2')  # 设置为两栏

# 获取当前目录下所有匹配 *_04_input.xyz 的文件，并按 base_name 递增排序
files = sorted([f for f in os.listdir('.') if re.match(r".*_04_input\.xyz$", f)])

if not files:
    print("⚠️ 未找到符合 *_04_input.xyz 格式的文件！")
else:
    for file in files:
        base_name = file.replace("_04_input.xyz", "")  # 提取 base_name
        with open(file, 'r') as f:
            lines = f.readlines()

        # 处理文件内容
        processed_lines = []
        isomer_count = 1
        for idx, line in enumerate(lines):
            if "Nimag" in line:
                # 删除 Nimag 后的内容
                trimmed_line = line.split("Nimag")[0].strip()
                # 确保在前面第二行插入 isomer
                if len(processed_lines) >= 1:
                    processed_lines.insert(-1, f"{base_name}_isomer {isomer_count}")
                else:
                    processed_lines.append(f"{base_name}_isomer {isomer_count}")
                isomer_count += 1
                # 添加修剪后的 Nimag 行
                processed_lines.append(trimmed_line)
            else:
                # 其他行保持不变，但处理 XYZ 坐标格式
                formatted_line = format_xyz_line(line)
                processed_lines.append(formatted_line)

        # 将文件名作为标题插入文档
        doc.add_heading(base_name, level=2)

        # 添加内容到 Word 文档
        for processed_line in processed_lines:
            paragraph = doc.add_paragraph(adjust_spacing(processed_line))
            paragraph.style.font.size = Pt(10)

    # 保存 Word 文档
    output_file = "output.docx"
    doc.save(output_file)
    print(f"✅ 任务完成，结果保存在 {output_file} 中！")
