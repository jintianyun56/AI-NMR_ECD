#!/bin/bash

# 遍历当前目录下所有以 "01_rr" 开头的文件
for file in 01_rr*; do
    # 检查文件是否存在（避免没有匹配文件时出错）
    if [ -e "$file" ]; then
        # 使用 sed 替换文件名中的 "01_rr" 为 "001_rr"
        new_name=$(echo "$file" | sed 's/^01_rr/001_rr/')
        
        # 重命名文件
        mv "$file" "$new_name"
        
        # 打印重命名结果
        echo "Renamed: $file -> $new_name"
    else
        echo "No files found starting with '01_rr'."
    fi
done