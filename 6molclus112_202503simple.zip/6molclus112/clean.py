#!/root/soft/anaconda3/envs/tjenv/bin/python
import os
import glob

def delete_related_files(base_name):
    """删除与 base_name 相关的文件"""
    # 定义要删除的文件模式
    patterns = [
        f"{base_name}_*.jpg",
        f"{base_name}_*.bmp",
        f"{base_name}_*.dat",
        f"{base_name}_*.png",
        f"{base_name}_*.tga",
        f"{base_name}0*.txt",
        f"{base_name}_0*.txt",
        f"{base_name}_*.csv"
    ]

    # 遍历文件模式并删除匹配的文件
    for pattern in patterns:
        for file in glob.glob(pattern):
            try:
                os.remove(file)
                print(f"Deleted: {file}")
            except Exception as e:
                print(f"Error deleting {file}: {e}")

def main():
    # 获取当前目录下所有的 .pdb 文件
    pdb_files = glob.glob("*.pdb")

    if not pdb_files:
        print("No .pdb files found in the current directory.")
        return

    # 遍历每个 .pdb 文件
    for pdb_file in pdb_files:
        # 提取 base_name（去掉 .pdb 后缀）
        base_name = os.path.splitext(pdb_file)[0]
        print(f"Found {pdb_file}. Deleting related files for base_name: {base_name}...")

        # 删除与 base_name 相关的文件
        delete_related_files(base_name)

if __name__ == "__main__":
    main()