#!/root/soft/anaconda3/envs/tjenv/bin/python

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import savgol_filter

# Function to normalize the Y-axis data to scale the maximum value to within [-10, 10]
def normalize_y(data, column_name='Y', scale=10):
    data[column_name] = pd.to_numeric(data[column_name], errors='coerce')  # Convert to numeric
    data = data.dropna(subset=[column_name])  # Remove invalid rows
    max_abs_value = data[column_name].abs().max()
    if max_abs_value != 0:  # Avoid division by zero
        data[column_name] = data[column_name] / max_abs_value * scale  # Scale to [-scale, scale]
    return data

# Function to ensure the Y-axis range is within [-10, 10] for a specific X range
def clip_y_in_range(data, column_name='Y', x_column='X', x_range=(200, 600), y_range=(-10, 10)):
    data_in_range = data[(data[x_column] >= x_range[0]) & (data[x_column] <= x_range[1])]
    if not data_in_range.empty:
        data.loc[(data[x_column] >= x_range[0]) & (data[x_column] <= x_range[1]), column_name] = \
            data_in_range[column_name].clip(y_range[0], y_range[1])
    return data

# Apply Savitzky-Golay filter for smoothing
def smooth_data(data, column_name='Y', window_length=31, polyorder=2):
    data[column_name] = savgol_filter(data[column_name], window_length=window_length, polyorder=polyorder)
    return data

# Apply linear fitting in a specific range
def linear_fit(data, x_column='X', y_column='Y', fit_range=(280, 600)):
    # Extract the data within the fit range
    fit_data = data[(data[x_column] >= fit_range[0]) & (data[x_column] <= fit_range[1])]
    if fit_data.empty:
        return data  # No data to fit

    # Perform linear regression
    coef = np.polyfit(fit_data[x_column], fit_data[y_column], 1)  # Linear fit
    linear_model = np.poly1d(coef)

    # Replace the data in the fit range with the linear model
    data.loc[(data[x_column] >= fit_range[0]) & (data[x_column] <= fit_range[1]), y_column] = \
        linear_model(data.loc[(data[x_column] >= fit_range[0]) & (data[x_column] <= fit_range[1]), x_column])
    return data

# Function to process and plot data
def process_and_plot(csv_file, txt_file):
    # Load the CSV file
    data1 = pd.read_csv(csv_file, header=None)

    # Select first two columns and rename them
    if data1.shape[1] >= 2:
        data1 = data1.iloc[:, [0, 1]]  # Select first two columns
        data1.columns = ['X', 'Y']  # Rename columns
    else:
        raise ValueError(f"The file {csv_file} does not have enough columns.")

    # Convert X and Y to numeric and drop invalid rows
    data1['X'] = pd.to_numeric(data1['X'], errors='coerce')
    data1['Y'] = pd.to_numeric(data1['Y'], errors='coerce')
    data1 = data1.dropna(subset=['X', 'Y'])  # Drop rows with invalid data

    # Filter rows within the X range
    data1 = data1.iloc[1:445]
    data1 = data1[(data1['X'] >= 200) & (data1['X'] <= 400)]

    # Normalize Y and clip it within [-10, 10]
    data1 = normalize_y(data1)
    data1 = clip_y_in_range(data1)

    # Apply heavy smoothing for Dataset 1
    data1 = smooth_data(data1, window_length=51, polyorder=3)

    # Apply linear fit in the range 350-400
    data1 = linear_fit(data1, fit_range=(350, 400))

    # Load the TXT file
    data2 = pd.read_csv(txt_file, sep='\s+', header=None)
    data2.columns = ['X', 'Y']

    # Convert X and Y to numeric and drop invalid rows
    data2['X'] = pd.to_numeric(data2['X'], errors='coerce')
    data2['Y'] = pd.to_numeric(data2['Y'], errors='coerce')
    data2 = data2.dropna(subset=['X', 'Y'])

    # Filter rows within the X range
    data2 = data2[(data2['X'] >= 200) & (data2['X'] <= 400)]

    # Normalize Y for Dataset 2
    data2 = normalize_y(data2)

    # Apply light smoothing for Dataset 2
    data2 = smooth_data(data2, window_length=31, polyorder=2)

    # Create dataset 3 as a mirrored version of dataset 2
    data3 = data2.copy()
    data3['Y'] = -data2['Y']

    # Generate labels without file extensions
    csv_label = os.path.splitext(os.path.basename(csv_file))[0]
    txt_label = os.path.splitext(os.path.basename(txt_file))[0]

    # Plot all curves
    plt.figure(figsize=(12, 9))  # Set 4:3 aspect ratio
    plt.plot(data1['X'], data1['Y'], label=f'{csv_label}', color='blue', linestyle='-', marker='o', markersize=4)
    plt.plot(data2['X'], data2['Y'], label=f'{txt_label}', color='red', linestyle='-', marker='x', markersize=4)
    plt.plot(data3['X'], data3['Y'], label=f'{txt_label} (Mirrored)', color='green', linestyle='--', marker='^', markersize=4)

    # Customize the axes
    plt.axhline(0, color='black', linewidth=0.8, linestyle='--')
    plt.axvline(200, color='black', linewidth=0.8)
    plt.xlim(200, 400)
    plt.ylim(-12, 12)  # Set Y-axis limits to [-12, 12]
    plt.xticks(range(200, 401, 20), fontsize=14, fontweight='bold')  # Increase font size and make bold
    plt.yticks(range(-12, 13, 2), fontsize=14, fontweight='bold')  # Increase font size and make bold

    # Customize labels and title
    plt.xlabel('Wavelength (nm)', fontsize=16, fontweight='bold')  # Label font size and weight
    plt.ylabel('Δε (M⁻¹ cm⁻¹)', fontsize=16, fontweight='bold')
    plt.title(f'Combined XY Curves for {csv_label}', fontsize=18, fontweight='bold')
    plt.legend(fontsize=14, loc='best')  # Increase legend font size
    plt.grid(False)

    # Save the plot as a high-resolution image
    output_file = f"{csv_label}_pmirror.jpg"
    plt.savefig(output_file, format='jpg', dpi=300)  # 300 DPI for high-quality image
    plt.close()
    print(f"Plot saved: {output_file}")

# Main script
def main():
    # Dynamically get the directory of the current script
    input_folder = os.path.dirname(os.path.abspath(__file__))

    # Find all CSV and TXT files
    csv_files = [f for f in os.listdir(input_folder) if f.endswith(".csv")]
    txt_files = [f for f in os.listdir(input_folder) if f.endswith(".txt")]

    # Pair CSV and TXT files based on matching prefixes
    for csv_file in csv_files:
        base_name = os.path.splitext(csv_file)[0]
        txt_file = f"{base_name}.txt"
        csv_path = os.path.join(input_folder, csv_file)
        txt_path = os.path.join(input_folder, txt_file)

        if txt_file in txt_files:
            process_and_plot(csv_path, txt_path)

if __name__ == "__main__":
    main()
