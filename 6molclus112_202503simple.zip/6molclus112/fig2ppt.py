#!/root/soft/anaconda3/envs/tjenv/bin/python
# Evaluate the averaged NMR chemical shifts
import os
import re
import glob
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN

def get_base_name(filename):
    """Extracts base_name from filenames using regex."""
    match = re.match(r"(.*)_\d+.*\.(jpg|png|txt|csv)", filename)
    return match.group(1) if match else None

def add_images_to_slide(slide, images):
    """Add images to a slide in a 2-row, 3-column layout with filenames."""
    positions = [
        (Inches(0.5), Inches(0.5)), (Inches(3.5), Inches(0.5)), (Inches(6.5), Inches(0.5)), 
        (Inches(0.5), Inches(3.5)), (Inches(3.5), Inches(3.5)), (Inches(6.5), Inches(3.5))
    ]

    for (img, pos) in zip(images, positions):
        pic = slide.shapes.add_picture(img, pos[0], pos[1], width=Inches(3))
        
        # Add text below the image as a filename caption
        left = pos[0]
        top = pos[1] + Inches(2.5)  # Adjust position below the image
        text_box = slide.shapes.add_textbox(left, top, Inches(3), Inches(0.5))
        text_frame = text_box.text_frame
        text_frame.text = os.path.basename(img)
        
        # Style the text
        text_frame.paragraphs[0].alignment = PP_ALIGN.CENTER
        text_frame.paragraphs[0].font.size = Pt(14)

def create_ppt_from_images():
    """Create a PowerPoint presentation from images grouped by base_name."""
    ppt = Presentation()

    # Find all jpg and png files
    image_files = sorted([f for f in os.listdir() if f.endswith((".jpg", ".png"))])
    
    # Group images by base_name
    base_name_dict = {}
    for image in image_files:
        base_name = get_base_name(image)
        if base_name:
            if base_name not in base_name_dict:
                base_name_dict[base_name] = []
            base_name_dict[base_name].append(image)

    # Create slides
    for base_name, images in base_name_dict.items():
        # Group images into batches of 6 per slide
        for i in range(0, len(images), 6):
            slide = ppt.slides.add_slide(ppt.slide_layouts[5])
            add_images_to_slide(slide, images[i:i+6])

    # Save PPT
    ppt_output = "images_presentation.pptx"
    ppt.save(ppt_output)
    print(f"Presentation saved as {ppt_output}")

if __name__ == "__main__":
    create_ppt_from_images()
