#!/root/soft/anaconda3/envs/tjenv/bin/python
# Evaluate the averaged NMR chemical shifts

import os
import re
from openpyxl import Workbook

def extract_energy_from_log(log_file, keyword):
    """Extract energy value from a .log file based on the given keyword."""
    with open(log_file, 'r') as file:
        lines = file.readlines()

    for i, line in enumerate(lines):
        if keyword in line:
            energy_line = lines[i].strip()
            energy_match = re.search(r'-?\d+\.\d+', energy_line)
            if energy_match:
                return float(energy_match.group())
    return None

def extract_boltzmann_weights_from_txt(txt_file):
    """Extract Boltzmann weight values from a *_08_sher01rate.txt file."""
    weights = []
    with open(txt_file, 'r') as file:
        lines = file.readlines()

    for line in lines:
        if "Boltzmann weight=" in line:
            weight_line = line.strip()
            weight_match = re.search(r'Boltzmann weight=(.{10})', weight_line)
            if weight_match:
                weights.append(weight_match.group(1).strip())
    return weights

def main():
    # 获取当前目录下所有匹配的 .log 和 .txt 文件，并按规则排序
    sp_files = sorted([file for file in os.listdir() if re.match(r'.*_05_sp_orca00\d+\.log$', file)])
    freq_files = sorted([file for file in os.listdir() if re.match(r'.*_04_freq_gau00\d+\.log$', file)])
    sher_files = sorted([file for file in os.listdir() if re.match(r'.*_08_sher01rate\.txt$', file)])

    if not sp_files and not freq_files and not sher_files:
        print("当前目录下找不到匹配的 .log 或 *_08_sher01rate.txt 文件。")
        return

    # 创建一个新的Excel工作簿
    wb = Workbook()
    ws = wb.active

    # 添加表头
    ws.append(['单点计算 (Single Point Energy) 文件名', 'FINAL SINGLE POINT ENERGY', 
               '频率计算 (Frequency Calculation) 文件名', 'Thermal correction to Gibbs Free Energy', 
               '文件名', 'Boltzmann 权重 (Boltzmann Weight)'])

    # 初始化行号
    row_idx = 2

    # 处理 sp_files（单点计算的 .log 文件 -> FINAL SINGLE POINT ENERGY）
    for sp_file in sp_files:
        energy_value = extract_energy_from_log(sp_file, "FINAL SINGLE POINT ENERGY")

        if energy_value is not None:
            ws.cell(row=row_idx, column=1, value=sp_file)
            ws.cell(row=row_idx, column=2, value=energy_value)
            row_idx += 1

    # 处理 freq_files（频率计算的 .log 文件 -> Thermal correction to Gibbs Free Energy）
    row_idx = 2  # Reset row index for freq data
    for freq_file in freq_files:
        gibbs_energy_value = extract_energy_from_log(freq_file, "Thermal correction to Gibbs Free Energy")

        if gibbs_energy_value is not None:
            ws.cell(row=row_idx, column=3, value=freq_file)
            ws.cell(row=row_idx, column=4, value=gibbs_energy_value)
            row_idx += 1

    # 处理 sher_files（Boltzmann 权重 -> *_08_sher01rate.txt）
    row_idx = 2  # Reset row index for sher data
    for sher_file in sher_files:
        weights = extract_boltzmann_weights_from_txt(sher_file)

        for weight_value in weights:
            ws.cell(row=row_idx, column=6, value=weight_value)
            ws.cell(row=row_idx, column=5, value=sher_file)
            row_idx += 1

    # 保存Excel文件
    output_file = 'energy_weights_data_sorted02.xlsx'
    wb.save(output_file)
    print(f"数据已成功写入 {output_file} 文件。")

if __name__ == "__main__":
    main()
